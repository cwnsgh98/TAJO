package com.tajo.dto;

public class Record {
	String userid;
	int distance;
	String ridedate;
	public String getUserid() {
		return userid;
	}

	public void setUserid(String userid) {
		this.userid = userid;
	}

	public String getRidedate() {
		return ridedate;
	}

	public void setRidedate(String ridedate) {
		this.ridedate = ridedate;
	}

	public int getDistance() {
		return distance;
	}

	public void setDistance(int distance) {
		this.distance = distance;
	}


	
}

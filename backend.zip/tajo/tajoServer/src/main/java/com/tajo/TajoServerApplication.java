package com.tajo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TajoServerApplication {

	public static void main(String[] args) {
		SpringApplication.run(TajoServerApplication.class, args);
	}

}
